
local function getComp(ped, id)
    local drawable = GetPedDrawableVariation(ped, id)
    local texture = GetPedTextureVariation(ped, id)
    if drawable ~= nil and texture ~= nil then
        return ("%d:%d"):format(drawable + 1, texture + 1)
    else
        return "0:0"
    end
end

local function getProp(ped, id)
    local drawable = GetPedPropIndex(ped, id)
    local texture = GetPedPropTextureIndex(ped, id)
    if drawable == -1 then return "0:0" end
    return ("%d:%d"):format(drawable + 1, texture + 1)
end

local function promptInput(promptText)
    AddTextEntry('FMMC_KEY_TIP1', promptText)
    DisplayOnscreenKeyboard(1, 'FMMC_KEY_TIP1', '', '', '', '', '', 30)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
        Wait(0)
    end
    if UpdateOnscreenKeyboard() == 2 then return nil end
    return GetOnscreenKeyboardResult()
end

RegisterCommand("copyeup", function()
    local name = promptInput("Enter Outfit Name")
    if not name then return end

    local category = promptInput("Enter Category")
    if not category then return end

    local category2 = promptInput("Enter Category 2")
    if not category2 then return end

    local ped = PlayerPedId()
    local drawableUS = GetPedDrawableVariation(ped, 3)
    local textureUS = GetPedTextureVariation(ped, 3)

    local eup = {
        Name = name,
        Gender = IsPedMale(ped) and "Male" or "Female",
        Category = category,
        Category2 = category2,
        Hat = getProp(ped, 0),
        Glasses = getProp(ped, 1),
        Ear = getProp(ped, 2),
        Watch = getProp(ped, 6),
        Mask = getComp(ped, 1),
        Top = getComp(ped, 11),
        UpperSkin = (drawableUS and textureUS) and ("%d:%d"):format(drawableUS + 1, textureUS + 1) or "0:0",
        Decal = getComp(ped, 10),
        UnderCoat = getComp(ped, 8),
        Pants = getComp(ped, 4),
        Shoes = getComp(ped, 6),
        Accessories = getComp(ped, 7),
        Armor = getComp(ped, 9),
        Parachute = getComp(ped, 5)
    }

    local orderedKeys = {
        "Name", "Gender", "Category", "Category2", "Hat", "Glasses", "Ear", "Watch",
        "Mask", "Top", "UpperSkin", "Decal", "UnderCoat", "Pants", "Shoes",
        "Accessories", "Armor", "Parachute"
    }

    local formatted = "{\n"
    for _, key in ipairs(orderedKeys) do
        local val = eup[key] or ""
        formatted = formatted .. string.format('  "%s": "%s",\n', key, val)
    end
    formatted = formatted:sub(1, -3) .. "\n}"

    print("^2[Outfit JSON]^0\n" .. formatted)
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(true)
    SendNUIMessage({
        type = "showJson",
        json = formatted
    })
end)

RegisterNUICallback("closePopup", function(_, cb)
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    cb({})
end)

-- Block mouse & aim controls while NUI is open
CreateThread(function()
    while true do
        Wait(0)
        if IsNuiFocused() then
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 140, true)
            DisableControlAction(0, 142, true)
            DisableControlAction(0, 257, true)
            DisableControlAction(0, 239, true)
        end
    end
end)

RegisterCommand("loadeup", function()
    local outfit = {
        Top = "201:3",
        UpperSkin = "14:1",
        Decal = "0:1",
        UnderCoat = "54:1",
        Pants = "26:3",
        Shoes = "55:1",
        Accessories = "7:1",
        Armor = "14:1",
        Parachute = "34:2",
        Mask = "122:1",
        Hat = "14:2",
        Glasses = "0:0",
        Ear = "0:0",
        Watch = "0:0"
    }

    local ped = PlayerPedId()

    local function applyComp(slotName, compId)
        local val = outfit[slotName]
        if val then
            local drawable, texture = string.match(val, "^(%d+):(%d+)$")
            if drawable and texture then
                SetPedComponentVariation(ped, compId, tonumber(drawable) - 1, tonumber(texture) - 1, 2)
            end
        end
    end

    local function applyProp(slotName, propId)
        local val = outfit[slotName]
        if val then
            local drawable, texture = string.match(val, "^(%d+):(%d+)$")
            if drawable and texture then
                ClearPedProp(ped, propId)
                SetPedPropIndex(ped, propId, tonumber(drawable) - 1, tonumber(texture) - 1, true)
            end
        end
    end

    applyComp("Mask", 1)
    applyComp("Top", 11)
    applyComp("UpperSkin", 3)
    applyComp("Decal", 10)
    applyComp("UnderCoat", 8)
    applyComp("Pants", 4)
    applyComp("Shoes", 6)
    applyComp("Accessories", 7)
    applyComp("Armor", 9)
    applyComp("Parachute", 5)

    applyProp("Hat", 0)
    applyProp("Glasses", 1)
    applyProp("Ear", 2)
    applyProp("Watch", 6)

    print("^2[Outfit Loader]^0 Outfit applied successfully.")
end)
