
fx_version 'cerulean'
game 'gta5'

client_script 'copyeup_cl.lua'

ui_page 'nui/index.html'

files {
  'nui/index.html'
}
